//Authors: Kenny Lieu, Baoviet(Jean) Duong

package levelPieces;

import gameEngine.Drawable;
import gameEngine.InteractionResult;

public class Pawn implements Drawable {

	public Pawn(int i) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw() {
		System.out.print('.');
		
	}


}
