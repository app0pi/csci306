package tests;

import java.awt.Color;
import java.util.HashSet;
import java.util.Set;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.BadConfigFormatException;
import clueGame.Board;
import clueGame.Card;
import clueGame.CardType;
import clueGame.Player;

public class gameSetupTests {
	
	private static Board board;
	@BeforeClass
	public static void setUp() throws BadConfigFormatException {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		//board.setConfigFiles("CTest_ClueLayout.csv", "CTest_ClueLegend.txt");	
		board.setConfigFiles("data/Layout.csv", "data/Legend.txt", "data/players.txt", "data/weapons.txt");		
		// Initialize will load BOTH config files 
		board.initialize();
	}
	
	
	@Test
	public void testPlayers()	{
		assertEquals(6, board.getPlayers().size());
		
		assertEquals("Cranjis McBasketball", board.getPlayer("Cranjis McBasketball").getPlayerName());
		assertEquals(Color.orange, board.getPlayer("Cranjis McBasketball").getColor());
		assertEquals(5, board.getPlayer("Cranjis McBasketball").getRow());
		assertEquals(3, board.getPlayer("Cranjis McBasketball").getColumn());
		
		assertEquals("Count Ravioli", board.getPlayer("Count Ravioli").getPlayerName());
		assertEquals(Color.red, board.getPlayer("Count Ravioli").getColor());
		assertEquals(7, board.getPlayer("Count Ravioli").getRow());
		assertEquals(3, board.getPlayer("Count Ravioli").getColumn());
		
		
		assertEquals("Shrek", board.getPlayer("Shrek").getPlayerName());
		assertEquals(Color.green, board.getPlayer("Shrek").getColor());
		assertEquals(10, board.getPlayer("Shrek").getRow());
		assertEquals(3, board.getPlayer("Shrek").getColumn());
		
		
	}
	
	@Test
	public void testCreateCards()	{
		//ensure all cards are accounted for
		assertEquals(21, board.getAllCards().size());
		
		//ensure there are 6 person cards
		int cardTypeCount=0;
		for(Card card : board.getAllCards()) {
			if(card.getCardType()==CardType.PERSON) {
				cardTypeCount++;
			}
		}
		assertEquals(6, cardTypeCount);
		
		//ensure there are 6 weapon cards
		cardTypeCount=0;
		for(Card card : board.getAllCards()) {
			if(card.getCardType()==CardType.WEAPON) {
				cardTypeCount++;
			}
		}
		assertEquals(6, cardTypeCount);
		
		//ensure there are 9 room cards
				cardTypeCount=0;
				for(Card card : board.getAllCards()) {
					if(card.getCardType()==CardType.ROOM) {
						cardTypeCount++;
					}
				}
		assertEquals(9, cardTypeCount);
		
		assertEquals("Food Court", board.getCard("Food Court").getCardName());
		assertEquals("Cinnabon", board.getCard("Cinnabon").getCardName());
		assertEquals("Hard Rock Cafe", board.getCard("Hard Rock Cafe").getCardName());
		
		assertEquals("Peach Turnip", board.getCard("Peach Turnip").getCardName());
		assertEquals("Chopsticks", board.getCard("Chopsticks").getCardName());
		assertEquals("Bone Hurting Juice", board.getCard("Bone Hurting Juice").getCardName());
		
		assertEquals("Cranjis McBasketball", board.getCard("Cranjis McBasketball").getCardName());
		assertEquals("Jerry Seinfeld", board.getCard("Jerry Seinfeld").getCardName());
		assertEquals("Shrek", board.getCard("Shrek").getCardName());	
		
		assertEquals(21, board.getCardDeck().size());
		
	}
	
	
	@Test
	public void testDealCards()	{
		board.dealCards();
		assertEquals(3, board.getSolutionDeck().size());
		
		System.out.println(board.getPlayer("Shrek").getPlayerName());
		
		assertEquals(3, board.getPlayer("Shrek").getCardHand().size());
		
		//ensure solution deck has a person card
		boolean hasType = false;
		for(Card solnCard : board.getSolutionDeck()) {
			if(solnCard.getCardType() == CardType.PERSON) {
				hasType=true;
			}
		}
		assertEquals(true, hasType);
		
		//ensure solution deck has a room card
		hasType = false;
		for(Card solnCard : board.getSolutionDeck()) {
			if(solnCard.getCardType() == CardType.ROOM) {
				hasType=true;
			}
		}
		
		assertEquals(true, hasType);
		
		//ensure solution deck has a weapon card
		hasType = false;
		for(Card solnCard : board.getSolutionDeck()) {
			if(solnCard.getCardType() == CardType.WEAPON) {
				hasType=true;
			}
		}
		assertEquals(true, hasType);
		
		
		//To make sure there are no duplicate cards among players U solution set,
		//they will all be added to a unique set, and we will check to make sure
		//this set contains all 21 cards.  (if there were duplicates, there would be 
		//less than 21 cards in testUniqueSet
		
		Set<Card> testUniqueSet = new HashSet<Card>();
		
		for(Player p : board.getPlayers()) {
			testUniqueSet.addAll(p.getCardHand());
		}
		testUniqueSet.addAll(board.getSolutionDeck());
		
		
		assertEquals(21, testUniqueSet.size());
		
	}
	
}
