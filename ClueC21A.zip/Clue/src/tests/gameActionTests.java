package tests;

import java.awt.Color;
import java.util.HashSet;
import java.util.Set;
import static org.junit.Assert.*;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue; //need this otherwise fail statement says ambiguous
import static org.junit.jupiter.api.Assertions.fail; //need this otherwise assertTrue statements say ambiguous
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.BeforeClass;
import org.junit.Test;
import clueGame.*;
import java.awt.Color;
import org.junit.BeforeClass;

public class gameActionTests {
	private static Board board;
	@BeforeClass
	public static void setUp() throws BadConfigFormatException {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("data/Layout.csv", "data/Legend.txt", "data/players.txt", "data/weapons.txt");		
		board.initialize();
	}

	//Test selecting a target - ComputerPlayer (random selection)
	@Test
	public void testTargetRandomSelection() {
		ComputerPlayer player = new ComputerPlayer();
		// Pick a location with no rooms in target, just five targets
		board.calcTargets(12, 10, 2);
		boolean loc_10_10 = false;
		boolean loc_11_9 = false;
		boolean loc_12_12 = false;
		boolean loc_12_8 = false;
		boolean loc_11_11 = false;
		// Run the test a large number of times
		for (int i=0; i<100; i++) {
			BoardCell selected = player.pickLocation(board.getTargets());
			if (selected == board.getCellAt(10, 10))
				loc_10_10 = true;
			else if (selected == board.getCellAt(11, 9))
				loc_11_9 = true;
			else if (selected == board.getCellAt(12, 12))
				loc_12_12 = true;
			else if (selected == board.getCellAt(12, 8))
				loc_12_8 = true;
			else if (selected == board.getCellAt(11, 11))
				loc_11_11 = true;
			else
				fail("Invalid target selected");
		}
		// Ensure each target was selected at least once
		assertTrue(loc_10_10);
		assertTrue(loc_11_9);
		assertTrue(loc_12_12);
		assertTrue(loc_12_8);
		assertTrue(loc_11_11);
	}


	//	Selecting a target location - ComputerPlayer (not random)
	@Test
	public void testTargetOneRoomSelection() {
		ComputerPlayer player = new ComputerPlayer();
		board.calcTargets(6, 19, 2);
		assertTrue(player.pickLocation(board.getTargets())==board.getCellAt(5, 18));
	}
	
	@Test
	public void testTargetRoomIsLastVisitedSelection()	{
		ComputerPlayer player = new ComputerPlayer();
		player.setRoomLastVisited('G');
		board.calcTargets(6, 19, 2);
		boolean loc_5_18 = false;
		boolean loc_6_17 = false;
		boolean loc_7_18 = false;
		boolean loc_8_19 = false;
		for (int i=0; i<100; i++) {
			BoardCell selected = player.pickLocation(board.getTargets());
			if (selected == board.getCellAt(5, 18))
				loc_5_18 = true;
			else if (selected == board.getCellAt(6, 17))
				loc_6_17 = true;
			else if (selected == board.getCellAt(7, 18))
				loc_7_18 = true;
			else if (selected == board.getCellAt(8, 19))
				loc_8_19 = true;
			else
				fail("Invalid target selected");
		}
		assertTrue(loc_5_18);
		assertTrue(loc_6_17);
		assertTrue(loc_7_18);
		assertTrue(loc_8_19);
	}

	//	Checking an accusation - Board
	@Test
	public void testAccusation() {
		
		//cards must be dealt in order to generate a solution for the game
		board.dealCards();
		
		Solution trueSolution = new Solution();

		
		
		
		//ensure we grab the correct cards to create the true soluti
		
		for(Card c : board.getSolutionDeck()) {
			if(c.getCardType()==CardType.PERSON) {
				trueSolution.person = c.getCardName();
			}
			if(c.getCardType()==CardType.ROOM) {
				trueSolution.room = c.getCardName();
			}
			if(c.getCardType()==CardType.WEAPON) {
				trueSolution.weapon = c.getCardName();
			}
		}
		
		
		
		assertTrue(board.checkAccusation(trueSolution));
		
		Solution falseSolution = new Solution();
		falseSolution.person = "";
		falseSolution.weapon = "";
		falseSolution.room = "";
		
		assertEquals(false, board.checkAccusation(falseSolution));
		
		


	}

	@Test
	//	Disproving a suggestion - Player
	public void testDisproveSuggestion() {
		
		Card testWeapon = new Card("weaponCard");
		Card testRoom = new Card("roomCard");
		Card testPerson = new Card("personCard");
		testWeapon.setCardType(CardType.WEAPON);
		testRoom.setCardType(CardType.ROOM);
		testPerson.setCardType(CardType.PERSON);
		
		Set<Card> testSet = new HashSet<Card>();
		testSet.add(testPerson); testSet.add(testRoom); testSet.add(testWeapon);
		
		ComputerPlayer testPlayer = new ComputerPlayer();
		testPlayer.setCardHand(testSet);
		
		Solution oneCardRightSuggestion = new Solution();
		oneCardRightSuggestion.weapon = testWeapon.getCardName();
		oneCardRightSuggestion.person = "NA";
		oneCardRightSuggestion.room = "NA";
		

		
		assertEquals(testWeapon, testPlayer.disproveSuggestion(oneCardRightSuggestion));
		
		//Test if all three match
		Solution threeCardSolution = new Solution();
		threeCardSolution.person = "personCard";
		threeCardSolution.room = "roomCard";
		threeCardSolution.weapon = "weaponCard";
		
		boolean weaponPicked=false;
		boolean roomPicked = false;
		boolean personPicked = false;
		
		for(int i=0; i<100; i++) {
			
			Card testCard = testPlayer.disproveSuggestion(threeCardSolution);
			
			if(testCard==testWeapon)	{
				weaponPicked=true;
			}
			else if(testCard==testRoom)	{
				roomPicked=true;
			}
			else if(testCard==testPerson)	{
				personPicked=true;
			}
			else	{
				fail("no cards picked");
			}
			
		}
		
		assertTrue(weaponPicked);
		assertTrue(roomPicked);
		assertTrue(personPicked);
		
		
		//test if none match
		Solution zeroCardSolution = new Solution();
		
		zeroCardSolution.person="NA";
		zeroCardSolution.room="NA";
		zeroCardSolution.weapon="NA";
		
		assertEquals(null, testPlayer.disproveSuggestion(zeroCardSolution));
		
		
	}

	@Test
	//	Handling a suggestion - Board
	public void testHandleSuggestion() {

		Card cpW = new Card("cp1Weapon");
		Card cpR = new Card("cp1Room");
		Card cpP = new Card("cp1Person");
		
		cpW.setCardType(CardType.WEAPON);
		cpR.setCardType(CardType.ROOM);
		cpP.setCardType(CardType.PERSON);
		
		
		
		Set<Player> players = new HashSet<Player>();
		ComputerPlayer cp1 = new ComputerPlayer();
		ComputerPlayer cp2 = new ComputerPlayer();
		HumanPlayer human = new HumanPlayer();
		
		players.add(cp1);
		players.add(cp2);
		players.add(human);
		
		Board.getInstance().testPlayers = players;
		
		
		

		Solution testSoln = new Solution();
		testSoln.person = "suggestedPerson";
		testSoln.weapon = "suggestedWeapon";
		testSoln.room = "suggestedRoom";
		
		//cp1.createSuggestion();
		Card testCard = Board.getInstance().handleSuggestion(testSoln, cp1, Board.getInstance().testPlayers);
		
		
		
		assertEquals(null, testCard);
		
		//only accusing player can disprove
		
		Card matchingCard = new Card("suggestedPerson");
		matchingCard.setCardType(CardType.PERSON);
		
		cp1.getCardHand().add(matchingCard);
		
		//cp1.createSuggestion();
		testCard = Board.getInstance().handleSuggestion(testSoln, cp1, Board.getInstance().testPlayers);
		
		assertEquals(null, testCard);		
		cp1.getCardHand().remove(matchingCard);
		
		
		//only human can disprove, cp is accuser, verify card returned
		human.getCardHand().add(matchingCard);
		//cp1.createSuggestion();
		testCard = Board.getInstance().handleSuggestion(testSoln, cp1, Board.getInstance().testPlayers);
		
		assertEquals(matchingCard, testCard);
		
		
		
		
		//only human can disprove, human is accuser, should return null
		//human.getCardHand().add(matchingCard);
		
		//human.createSuggestion();
		testCard = Board.getInstance().handleSuggestion(testSoln, human, Board.getInstance().testPlayers);
		
		assertEquals(null, testCard);
		
		human.getCardHand().remove(matchingCard);
		
		Card matchingCard2 = new Card("suggestedWeapon");
		matchingCard2.setCardType(CardType.WEAPON);
		
		cp2.getCardHand().add(matchingCard2);
		
		testCard = Board.getInstance().handleSuggestion(testSoln, cp1, Board.getInstance().testPlayers);
		
		System.out.println("matching card 2: " + matchingCard2.getCardName());
		System.out.println("testCard: " + testCard.getCardName());
		
		assertEquals(matchingCard2, testCard);
		
		
		
	}

	@Test
	//	Creating a suggestion - ComputerPlayer
	public void testCreateSuggestion() {
		Card roomCard = new Card("NA");
		for(Card c : Board.getInstance().getAllCards())	{
			
			if(c.getCardName().equals("Haagen Dazs"))	{
				roomCard = c;
			}
		}
		
		
		
		ComputerPlayer cp = new ComputerPlayer();
		cp.setRow(5);
		cp.setColumn(16);
		
		cp.getSeenCards().addAll(Board.getInstance().getAllCards());
		
		

		//remove the first weapon card we see
		Card weaponCard = new Card("NA");
		Card personCard = new Card("NA");
		Card weaponCard2 = new Card("NA");
		Card personCard2 = new Card("NA");
		
		for(Card c : cp.getSeenCards()) {
			if (c.getCardType() == CardType.WEAPON)	{
				weaponCard = c;				
				break;
			}					
		}
		for(Card c : cp.getSeenCards()) {
			if (c.getCardType() == CardType.PERSON)	{
				personCard = c;				
				break;
			}					
		}
		System.out.println("list size: " + cp.getSeenCards().size());
		System.out.println("removing: " + weaponCard.getCardName());
		cp.getSeenCards().remove(weaponCard);
		cp.getSeenCards().remove(personCard);
		
		System.out.println("list size after removal: " + cp.getSeenCards().size());
		
		
		cp.createSuggestion();	
		
		
		//If only one weapon not seen, it's selected
		assertEquals(weaponCard.getCardName(), cp.currentSuggestion.weapon);		
		//room matches current location
		assertEquals(roomCard.getCardName(), cp.currentSuggestion.room);
		//If only one person not seen, it's selected
		assertEquals(personCard.getCardName(), cp.currentSuggestion.person);	
		
		for(Card c : cp.getSeenCards()) {
			if (c.getCardType() == CardType.WEAPON)	{
				weaponCard2 = c;				
				break;
			}					
		}
		for(Card c : cp.getSeenCards()) {
			if (c.getCardType() == CardType.PERSON)	{
				personCard2 = c;				
				break;
			}					
		}
		System.out.println("list size: " + cp.getSeenCards().size());
		
		
		System.out.println("removing: " + weaponCard2.getCardName());
		cp.getSeenCards().remove(weaponCard2);
		cp.getSeenCards().remove(personCard2);

		
		System.out.println("list size after removal: " + cp.getSeenCards().size());
		
		cp.createSuggestion();
		
		boolean weapon1 = false;
		boolean weapon2 = false;
		boolean person1 = false;
		boolean person2 = false;
		
		for(int i=0; i<100; i++) {
			cp.createSuggestion();
			
			if(cp.currentSuggestion.weapon == weaponCard.getCardName()) {
				weapon1=true;
			}
			else if(cp.currentSuggestion.weapon == weaponCard2.getCardName()) {
				weapon2=true;
			}
			else 	{
				fail("no card found");
			}
			
		}
		
		//If multiple weapons not seen, one of them is randomly selected
		assertEquals(true, weapon1);
		assertEquals(true, weapon2);
		
		for(int i=0; i<100; i++) {
			cp.createSuggestion();
			
			if(cp.currentSuggestion.person == personCard.getCardName()) {
				person1=true;
			}
			else if(cp.currentSuggestion.person == personCard2.getCardName()) {
				person2=true;
			}
			else 	{
				fail("no card found");
			}
			
		}
		
		//If multiple persons not seen, one of them is randomly selected
		assertEquals(true, person1);
		assertEquals(true, person2);

	}
}
