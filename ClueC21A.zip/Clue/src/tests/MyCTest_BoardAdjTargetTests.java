//Authors: Jared Hamilton and Kenny Lieu
//JUnit Test for OUR clue layout

package tests;

/*
 * This program tests that adjacencies and targets are calculated correctly.
 */

import java.util.Set;

//Doing a static import allows me to write assertEquals rather than
//assertEquals
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.BadConfigFormatException;
import clueGame.Board;
import clueGame.BoardCell;

public class MyCTest_BoardAdjTargetTests {
	// We make the Board static because we can load it one time and 
	// then do all the tests. 
	private static Board board;
	@BeforeClass
	public static void setUp() throws BadConfigFormatException {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		//board.setConfigFiles("CTest_ClueLayout.csv", "CTest_ClueLegend.txt");	
		board.setConfigFiles("data/Layout.csv", "data/Legend.txt", "data/players.txt", "data/weapons.txt");		
		// Initialize will load BOTH config files 
		board.initialize();
	}

	// Ensure that player does not move around within room
	// These cells are ORANGE on the planning spreadsheet
	@Test
	public void testAdjacenciesInsideRooms()
	{
		// Test a corner
		Set<BoardCell> testList = board.getAdjList(0,0);
		assertEquals(0, testList.size());
		// Test one that has walkway underneath
		testList = board.getAdjList(5, 7);
		assertEquals(0, testList.size());
		// Test one that has walkway above
		testList = board.getAdjList(13, 5);
		assertEquals(0, testList.size());
		// Test one that is in middle of room
		testList = board.getAdjList(4,1);
		assertEquals(0, testList.size());
		// Test one beside a door
		testList = board.getAdjList(8, 20);
		assertEquals(0, testList.size());
		// Test one in a corner of room
		testList = board.getAdjList(5, 5);
		assertEquals(0, testList.size());
	}

	// Ensure that the adjacency list from a doorway is only the
	// walkway. NOTE: This test could be merged with door 
	// direction test. 
	// These tests are PURPLE on the planning spreadsheet
	@Test
	public void testAdjacencyRoomExit()
	{
		// TEST DOORWAY RIGHT 
		Set<BoardCell> testList = board.getAdjList(1, 11);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(1, 12)));
		// TEST DOORWAY LEFT 
		testList = board.getAdjList(1, 14);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(1, 13)));
		//TEST DOORWAY DOWN
		testList = board.getAdjList(5, 16);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(6, 16)));
		//TEST DOORWAY UP
		testList = board.getAdjList(13, 2);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(12, 2)));
		//TEST DOORWAY RIGHT, WHERE THERE'S A WALKWAY BELOW
		testList = board.getAdjList(11, 3);




		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(11, 4)));

	}

	// Test adjacency at entrance to rooms
	// These tests are GREEN in planning spreadsheet
	@Test
	public void testAdjacencyDoorways()
	{
		// Test beside a door direction RIGHT
		Set<BoardCell> testList = board.getAdjList(11, 4);
		assertEquals(4, testList.size());
		assertTrue(testList.contains(board.getCellAt(11, 3)));
		assertTrue(testList.contains(board.getCellAt(12, 4)));
		assertTrue(testList.contains(board.getCellAt(10, 4)));
		assertTrue(testList.contains(board.getCellAt(11, 5)));

		// Test beside a door direction LEFT
		testList = board.getAdjList(1, 13);






		assertEquals(4, testList.size());

		assertTrue(testList.contains(board.getCellAt(1, 14)));
		assertTrue(testList.contains(board.getCellAt(1, 12)));
		assertTrue(testList.contains(board.getCellAt(2, 13)));
		assertTrue(testList.contains(board.getCellAt(0, 13)));

		// Test beside a door direction DOWN
		testList = board.getAdjList(6, 9);
		assertEquals(4, testList.size());
		assertTrue(testList.contains(board.getCellAt(5, 9)));
		assertTrue(testList.contains(board.getCellAt(7, 9)));
		assertTrue(testList.contains(board.getCellAt(6, 10)));
		assertTrue(testList.contains(board.getCellAt(6, 8)));



		// Test beside a door direction UP
		testList = board.getAdjList(12, 7);
		assertEquals(4, testList.size());
		assertTrue(testList.contains(board.getCellAt(13, 7)));
		assertTrue(testList.contains(board.getCellAt(11, 7)));
		assertTrue(testList.contains(board.getCellAt(12, 8)));
		assertTrue(testList.contains(board.getCellAt(12, 6)));

	}

	// Test a variety of walkway scenarios
	// These tests are LIGHT PURPLE on the planning spreadsheet
	@Test
	public void testAdjacencyWalkways()
	{
		// Test on top edge of board, 2 walkway pieces
		Set<BoardCell> testList = board.getAdjList(0, 12);
		assertTrue(testList.contains(board.getCellAt(0, 13)));
		assertTrue(testList.contains(board.getCellAt(1, 12)));
		assertEquals(2, testList.size());

		// Test on left edge of board, one walkway piece
		testList = board.getAdjList(12, 0);
		assertTrue(testList.contains(board.getCellAt(12, 1)));

		assertEquals(1, testList.size());

		// Test between two rooms, walkways right and left
		testList = board.getAdjList(3, 4);
		assertTrue(testList.contains(board.getCellAt(2, 4)));
		assertTrue(testList.contains(board.getCellAt(4, 4)));
		assertEquals(2, testList.size());

		// Test surrounded by 4 walkways
		testList = board.getAdjList(9,17);
		assertTrue(testList.contains(board.getCellAt(9, 18)));
		assertTrue(testList.contains(board.getCellAt(9, 16)));
		assertTrue(testList.contains(board.getCellAt(8, 17)));
		assertTrue(testList.contains(board.getCellAt(10, 17)));
		assertEquals(4, testList.size());


		// Test on walkway next to  door that is not in the needed
		// direction to enter
		testList = board.getAdjList(12, 3);
		assertTrue(testList.contains(board.getCellAt(12,4)));
		assertTrue(testList.contains(board.getCellAt(12,2)));
		assertEquals(2, testList.size());

	}


	// Tests of just walkways, 1 step, includes on edge of board
	// and beside room
	// Have already tested adjacency lists on all four edges, will
	// only test two edges here
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testTargetsOneStep() {

		//edge of board
		board.calcTargets(0, 4, 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(1, targets.size());
		assertTrue(targets.contains(board.getCellAt(1, 4)));

		//beside room
		board.calcTargets(12, 11, 1);
		targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCellAt(12, 12)));
		assertTrue(targets.contains(board.getCellAt(12, 10)));	
		assertTrue(targets.contains(board.getCellAt(11, 11)));			
	}

	// Tests of just walkways, 2 steps
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testTargetsTwoSteps() {

		//only walkways surrounding space
		board.calcTargets(9, 9, 2);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(7, targets.size());

		assertTrue(targets.contains(board.getCellAt(8, 8)));
		assertTrue(targets.contains(board.getCellAt(10, 8)));
		assertTrue(targets.contains(board.getCellAt(8, 10)));
		assertTrue(targets.contains(board.getCellAt(10, 10)));
		assertTrue(targets.contains(board.getCellAt(7, 9)));
		assertTrue(targets.contains(board.getCellAt(11, 9)));
		assertTrue(targets.contains(board.getCellAt(9, 11)));

		//adjacent to room
		board.calcTargets(6, 14, 2);
		targets= board.getTargets();
		assertEquals(6, targets.size());
		assertTrue(targets.contains(board.getCellAt(7, 13)));
		assertTrue(targets.contains(board.getCellAt(5, 13)));	
		assertTrue(targets.contains(board.getCellAt(8, 14)));		
		assertTrue(targets.contains(board.getCellAt(7, 15)));	
		assertTrue(targets.contains(board.getCellAt(6, 16)));
		assertTrue(targets.contains(board.getCellAt(6, 12)));
	}

	// Tests of just walkways, 4 steps
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testTargetsFourSteps() {


		board.calcTargets(9, 14, 4);
		Set<BoardCell> targets= board.getTargets();


		assertEquals(16, targets.size());
		assertTrue(targets.contains(board.getCellAt(6, 13)));
		assertTrue(targets.contains(board.getCellAt(6, 15)));
		assertTrue(targets.contains(board.getCellAt(7, 12)));
		assertTrue(targets.contains(board.getCellAt(7, 14)));

		assertTrue(targets.contains(board.getCellAt(7, 16)));

		assertTrue(targets.contains(board.getCellAt(8, 15)));
		assertTrue(targets.contains(board.getCellAt(8, 17)));


		assertTrue(targets.contains(board.getCellAt(9, 16)));
		assertTrue(targets.contains(board.getCellAt(9, 18)));


		assertTrue(targets.contains(board.getCellAt(10, 15)));
		assertTrue(targets.contains(board.getCellAt(10, 17)));
		assertTrue(targets.contains(board.getCellAt(11, 12)));
		assertTrue(targets.contains(board.getCellAt(11, 14)));

		assertTrue(targets.contains(board.getCellAt(11, 16)));
		assertTrue(targets.contains(board.getCellAt(12, 13)));
		assertTrue(targets.contains(board.getCellAt(12, 15)));


		// Includes a path that doesn't have enough length
		board.calcTargets(0, 4, 4);
		targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCellAt(4, 4)));
		assertTrue(targets.contains(board.getCellAt(2, 3)));

	}	

	// Tests of just walkways plus one door, 6 steps
	// These are LIGHT BLUE on the planning spreadsheet

	@Test
	public void testTargetsSixSteps() {
		board.calcTargets(0, 13, 6);
		Set<BoardCell> targets= board.getTargets();


		Set<BoardCell> adj = board.getAdjList(1, 13);
		Set<BoardCell> adj1 = board.getAdjList(0, 13);

		assertEquals(4, targets.size());



		assertTrue(targets.contains(board.getCellAt(6, 13)));
		assertTrue(targets.contains(board.getCellAt(4, 13)));
		//doorway shortcuts:
		assertTrue(targets.contains(board.getCellAt(1, 14)));
		assertTrue(targets.contains(board.getCellAt(1, 11)));
	}	

	// Test getting into a room
	// These are LIGHT BLUE on the planning spreadsheet

	@Test 
	public void testTargetsIntoRoom()
	{
		// One room is exactly 2 away
		board.calcTargets(1, 13, 2);
		Set<BoardCell> targets= board.getTargets();


		assertEquals(4, targets.size());

		assertTrue(targets.contains(board.getCellAt(1, 11)));
		assertTrue(targets.contains(board.getCellAt(3, 13)));
		assertTrue(targets.contains(board.getCellAt(1, 14)));
		assertTrue(targets.contains(board.getCellAt(0, 12)));

	}

	// Test getting into room, doesn't require all steps
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testTargetsIntoRoomShortcut() 
	{
		board.calcTargets(6, 17, 3);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(11, targets.size());
		// two doors within range that we shortcut into:
		assertTrue(targets.contains(board.getCellAt(5, 16)));
		assertTrue(targets.contains(board.getCellAt(5, 18)));
		// directly left and 
		assertTrue(targets.contains(board.getCellAt(6, 14)));		
		assertTrue(targets.contains(board.getCellAt(6, 16)));

		//directly right (1 cannot be accessed)
		assertTrue(targets.contains(board.getCellAt(6, 18)));

		//3 cells that can be accessed on row below (1 cannot be reached)
		assertTrue(targets.contains(board.getCellAt(7, 15)));		
		assertTrue(targets.contains(board.getCellAt(7, 17)));
		assertTrue(targets.contains(board.getCellAt(7, 19)));

		//two cells 2 rows down that can be accessed from the start
		assertTrue(targets.contains(board.getCellAt(8, 16)));		
		assertTrue(targets.contains(board.getCellAt(8, 18)));

		//3 cells directly down
		assertTrue(targets.contains(board.getCellAt(9, 17)));		



	}

	// Test getting out of a room
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testRoomExit()
	{
		// Take one step, essentially just the adj list
		board.calcTargets(13, 13, 1);
		Set<BoardCell> targets= board.getTargets();

		// Ensure doesn't exit through the wall
		assertEquals(1, targets.size());
		assertTrue(targets.contains(board.getCellAt(12, 13)));
		// Take two steps
		board.calcTargets(13, 13, 2);
		targets= board.getTargets();



		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCellAt(11, 13)));
		assertTrue(targets.contains(board.getCellAt(12, 12)));
		assertTrue(targets.contains(board.getCellAt(12, 14)));
	}

}
