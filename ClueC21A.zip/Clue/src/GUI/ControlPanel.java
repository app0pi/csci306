package GUI;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import clueGame.Board;

public class ControlPanel extends JPanel {

	//This class is a singleton
	private static ControlPanel thisControlPanel;
	private ControlPanel()	{}

	public static ControlPanel getInstance()	{
		if (thisControlPanel == null)
			thisControlPanel=new ControlPanel();
		return thisControlPanel;
	}

	public void initialize(JFrame parentFrame) {
		thisControlPanel.setSize(parentFrame.getWidth(), parentFrame.getHeight()/5);		
		thisControlPanel.setLayout(null);
		createButtonPanel();
		createTextPanels();
		
	}
	
	//button clicked methods
	
	private void nextPlayerClicked(ActionEvent e)	{
		
	}
	
	private void makeAccusationClicked(ActionEvent e)	{
		
	}
	
	

	private void createButtonPanel() {
		// no layout specified, so this is flow
		JButton nextPlayer = new JButton("Next player");
		JButton makeAccusation = new JButton("Make an accustation");
		
		JPanel buttonPanel = new JPanel();
		
		buttonPanel.setSize((thisControlPanel.getWidth()*2)/3, thisControlPanel.getHeight()/2);
		buttonPanel.setLocation(new Point(thisControlPanel.getWidth()-buttonPanel.getWidth(), 0));
		
		System.out.println(thisControlPanel.getWidth());
		
		buttonPanel.setLayout(null);
		
		thisControlPanel.add(buttonPanel);
		
		nextPlayer.setSize(buttonPanel.getWidth()/2, buttonPanel.getHeight());
		makeAccusation.setSize(buttonPanel.getWidth()/2, buttonPanel.getHeight());
		
		buttonPanel.add(nextPlayer);
		buttonPanel.add(makeAccusation);
		
		nextPlayer.setLocation(new Point(0,0));
		makeAccusation.setLocation(new Point(makeAccusation.getWidth(), 0));
		
		nextPlayer.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
			    nextPlayerClicked(e);
			  } 
		} );
		
		makeAccusation.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
			    makeAccusationClicked(e);
			  } 
		} );
		
		
		
	}
	
	private void createTextPanels()	{
		JPanel turnPanel = new JPanel();
		JPanel guessPanel = new JPanel();
		JPanel resultPanel = new JPanel();
		JPanel diePanel = new JPanel();
		
		//turnPanel relative size and location
		turnPanel.setSize(thisControlPanel.getWidth()/3, thisControlPanel.getHeight()/2);
		turnPanel.setLocation(new Point(0,0));
		
		//diePanel relative size and location
		diePanel.setSize(thisControlPanel.getWidth()/3, thisControlPanel.getHeight()/2);
		diePanel.setLocation(new Point(0,turnPanel.getHeight()));
		
		//guessPanel relative size and location
		guessPanel.setSize(thisControlPanel.getWidth()/3, thisControlPanel.getHeight()/2);
		guessPanel.setLocation(new Point(diePanel.getWidth(), turnPanel.getHeight()));
				
		//resultPanel relative size and location
		resultPanel.setSize(thisControlPanel.getWidth()/3, thisControlPanel.getHeight()/2);
		resultPanel.setLocation(new Point(diePanel.getWidth()+guessPanel.getWidth(), turnPanel.getHeight()));
		
		//diePanel border
		TitledBorder dieBorder = new TitledBorder("Die");
		dieBorder.setTitleJustification(TitledBorder.LEFT);
		dieBorder.setTitlePosition(TitledBorder.TOP);
	    diePanel.setBorder(dieBorder);
	    
		//guessPanel border
		TitledBorder guessBorder = new TitledBorder("Guess");
		guessBorder.setTitleJustification(TitledBorder.LEFT);
		guessBorder.setTitlePosition(TitledBorder.TOP);
	    guessPanel.setBorder(guessBorder);
	    
		//resultPanel border
		TitledBorder resultBorder = new TitledBorder("Guess Result");
		resultBorder.setTitleJustification(TitledBorder.LEFT);
		resultBorder.setTitlePosition(TitledBorder.TOP);
		resultPanel.setBorder(resultBorder);
	    
	    
		
		//add contents to turnPanel
		JLabel turnLabel1 = new JLabel("Whose turn?");
		JLabel turnLabel2 = new JLabel("Shrek");
		turnPanel.add(turnLabel1);
		turnPanel.add(turnLabel2);
		

		
		//add contents to diePanel
		diePanel.setAlignmentX(CENTER_ALIGNMENT);
		JLabel dieLabel1 = new JLabel("Roll");
		JLabel dieLabel2 = new JLabel("        4        ");
		//dieLabel1.setAlignmentX(LEFT_ALIGNMENT);
		dieLabel2.setBorder(new TitledBorder(""));
		diePanel.add(dieLabel1);
		diePanel.add(dieLabel2);
		
		//add contents to guessPanel
		guessPanel.setAlignmentX(CENTER_ALIGNMENT);
		//guessPanel.setLayout(new GridLayout());
		JLabel guessLabel1 = new JLabel("Guess");
		JLabel guessLabel2 = new JLabel("                ");  //16 empty spaces
		guessLabel2.setBorder(new TitledBorder(""));
		guessPanel.add(guessLabel1);
		guessPanel.add(guessLabel2);
		
		
		//add contents to resultPanel
		resultPanel.setAlignmentX(CENTER_ALIGNMENT);
		JLabel resultLabel1 = new JLabel("Response");
		JLabel resultLabel2 = new JLabel("                ");  //16 empty spaces
		resultLabel2.setBorder(new TitledBorder(""));
		resultPanel.add(resultLabel1);
		resultPanel.add(resultLabel2);
		
		
		//add text panels to control panel
		thisControlPanel.add(turnPanel);
		thisControlPanel.add(diePanel);
		thisControlPanel.add(guessPanel);
		thisControlPanel.add(resultPanel);
		
	}
}

	
