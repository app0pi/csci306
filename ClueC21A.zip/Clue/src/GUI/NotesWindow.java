package GUI;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import clueGame.Board;
import clueGame.Card;
import clueGame.CardType;

public class NotesWindow extends JDialog{ //note the rubric says it HAS to be a dialog not a JFrame
	private static NotesWindow thisNotesWindow;
	private NotesWindow()	{
		this.setVisible(false);
	}

	public static NotesWindow getInstance()	{
		if (thisNotesWindow == null)
			thisNotesWindow=new NotesWindow();
		return thisNotesWindow;	
	}

	public void initialize() {
		thisNotesWindow.setSize(600, 800); 
		thisNotesWindow.setLayout(null); 
		
		//I listed these out but we'll definitely condense these into createTextPanels and createDropboxes or something:
		this.add(createPeoplePanel());
		this.add(createRoomPanel());
		this.add(createWeaponPanel());
		this.add(createGuessBox());
	}

	private Component createGuessBox() {
		JPanel panel = new JPanel();
		panel.setLocation(this.getWidth()/2, 0);
		panel.setSize(this.getWidth()/2, this.getHeight()-45);
	
		panel.setLayout(null);
		
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		JPanel p3 = new JPanel();
		
		panel.add(p1);
		panel.add(p2);
		panel.add(p3);
		
		p1.setLocation(0,0);
		p1.setSize(panel.getWidth(), panel.getHeight()/3);
		
		p2.setLocation(0, panel.getHeight()/3);
		p2.setSize(panel.getWidth(), panel.getHeight()/3);
		
		p3.setLocation(0, panel.getHeight() * 2/3);
		p3.setSize(panel.getWidth(), panel.getHeight()/3);
		
		
		TitledBorder border1 = new TitledBorder("Person Guess");
		border1.setTitleJustification(TitledBorder.LEFT);
		border1.setTitlePosition(TitledBorder.TOP);
		p1.setBorder(border1);
		
		TitledBorder border2 = new TitledBorder("Room Guess");
		border2.setTitleJustification(TitledBorder.LEFT);
		border2.setTitlePosition(TitledBorder.TOP);
		p2.setBorder(border2);
		
		TitledBorder border3 = new TitledBorder("Weapon Guess");
		border3.setTitleJustification(TitledBorder.LEFT);
		border3.setTitlePosition(TitledBorder.TOP);
		p3.setBorder(border3);
		
		
		JComboBox<String> c1 = new JComboBox();
		c1.setLocation(0,0);
		c1.setSize(p1.getWidth()/2, p1.getHeight()-5);
		p1.add(c1);
		
		
		JComboBox<String> c2 = new JComboBox();
		c2.setLocation(0,0);
		c2.setSize(p2.getWidth()/2, p2.getHeight()-5);
		p2.add(c2);
		
		
		JComboBox<String> c3 = new JComboBox();
		c3.setLocation(0,0);
		c3.setSize(p3.getWidth()/2, p3.getHeight()-5);
		p3.add(c3);
		
		for(Card c : Board.getInstance().getAllCards())	{
			if(c.getCardType() == CardType.PERSON) {
				c1.addItem(c.getCardName());
			}
			if(c.getCardType() == CardType.ROOM) {
				c2.addItem(c.getCardName());
			}
			if(c.getCardType() == CardType.WEAPON) {
				c3.addItem(c.getCardName());
			}
		}
		
		
		return panel;
		
		
	}

	private JPanel createRoomPanel() {

		JPanel roomPanel = new JPanel();
		roomPanel.setLayout(new BoxLayout(roomPanel, BoxLayout.Y_AXIS));
		
		
		JCheckBox cb1 = new JCheckBox();
		JLabel lb1 = new JLabel("Food Court");
		JPanel p1 = new JPanel();
		
		JCheckBox cb2 = new JCheckBox();
		JLabel lb2 = new JLabel("Panda Express");
		JPanel p2 = new JPanel();
		
		JCheckBox cb3 = new JCheckBox();
		JLabel lb3 = new JLabel("Chick-fil-A");
		JPanel p3 = new JPanel();
		
		JCheckBox cb4 = new JCheckBox();
		JLabel lb4 = new JLabel("Cinnabon");
		JPanel p4 = new JPanel();
		
		JCheckBox cb5 = new JCheckBox();
		JLabel lb5 = new JLabel("Macy's");
		JPanel p5 = new JPanel();
		
		JCheckBox cb6 = new JCheckBox();
		JLabel lb6 = new JLabel("Victoria's Secret");
		JPanel p6 = new JPanel();
		
		JCheckBox cb7 = new JCheckBox();
		JLabel lb7 = new JLabel("Gamestop");
		JPanel p7 = new JPanel();
		
		JCheckBox cb8 = new JCheckBox();
		JLabel lb8 = new JLabel("Haagen Dazs");
		JPanel p8 = new JPanel();
		
		JCheckBox cb9 = new JCheckBox();
		JLabel lb9 = new JLabel("Hard Rock Cafe");
		JPanel p9 = new JPanel();
		
		p1.add(cb1);
		p1.add(lb1);
		
		
		p2.add(cb2);
		p2.add(lb2);
		
		p3.add(cb3);
		p3.add(lb3);
		
		p4.add(cb4);
		p4.add(lb4);
		
		p5.add(cb5);
		p5.add(lb5);
		
		p6.add(cb6);
		p6.add(lb6);
		
		p4.add(cb7);
		p4.add(lb7);
		
		p5.add(cb8);
		p5.add(lb8);
		
		p6.add(cb9);
		p6.add(lb9);
		
		roomPanel.add(p1); roomPanel.add(p2); roomPanel.add(p3); roomPanel.add(p4); roomPanel.add(p5); roomPanel.add(p6);
		roomPanel.add(p7); roomPanel.add(p8); roomPanel.add(p9);
		
		//format this peoplePanel
		roomPanel.setLocation(0,this.getHeight()/3 - 15);
		roomPanel.setSize(this.getWidth()/2, this.getHeight()/3-15);
		TitledBorder border = new TitledBorder("Rooms");
		border.setTitleJustification(TitledBorder.LEFT);
		border.setTitlePosition(TitledBorder.TOP);
		roomPanel.setBorder(border);
		
		return roomPanel;
		
	}

	private JPanel createPeoplePanel() {

		JPanel peoplePanel = new JPanel();
		peoplePanel.setLayout(new BoxLayout(peoplePanel, BoxLayout.Y_AXIS));
		
		
		JCheckBox cb1 = new JCheckBox();
		JLabel lb1 = new JLabel("Cranjis McBasketball");
		JPanel p1 = new JPanel();
		
		JCheckBox cb2 = new JCheckBox();
		JLabel lb2 = new JLabel("Dr. Shrimp Puerto Rico");
		JPanel p2 = new JPanel();
		
		JCheckBox cb3 = new JCheckBox();
		JLabel lb3 = new JLabel("Count Ravioli");
		JPanel p3 = new JPanel();
		
		JCheckBox cb4 = new JCheckBox();
		JLabel lb4 = new JLabel("Jerry Seinfeld");
		JPanel p4 = new JPanel();
		
		JCheckBox cb5 = new JCheckBox();
		JLabel lb5 = new JLabel("Anthony Panthony");
		JPanel p5 = new JPanel();
		
		JCheckBox cb6 = new JCheckBox();
		JLabel lb6 = new JLabel("Shrek");
		JPanel p6 = new JPanel();
		
		p1.add(cb1);
		p1.add(lb1);
		
		
		p2.add(cb2);
		p2.add(lb2);
		
		p3.add(cb3);
		p3.add(lb3);
		
		p4.add(cb4);
		p4.add(lb4);
		
		p5.add(cb5);
		p5.add(lb5);
		
		p6.add(cb6);
		p6.add(lb6);
		
		peoplePanel.add(p1); peoplePanel.add(p2); peoplePanel.add(p3); peoplePanel.add(p4); peoplePanel.add(p5); peoplePanel.add(p6);
		
		
		//format this peoplePanel
		peoplePanel.setLocation(0,0);
		peoplePanel.setSize(this.getWidth()/2, this.getHeight()/3-15);
		TitledBorder border = new TitledBorder("People");
		border.setTitleJustification(TitledBorder.LEFT);
		border.setTitlePosition(TitledBorder.TOP);
		peoplePanel.setBorder(border);
		
		return peoplePanel;
		
	}
	
	private JPanel createWeaponPanel() {

		JPanel weaponPanel = new JPanel();
		weaponPanel.setLayout(new BoxLayout(weaponPanel, BoxLayout.Y_AXIS));
		
		
		JCheckBox cb1 = new JCheckBox();
		JLabel lb1 = new JLabel("Peach Turnip");
		JPanel p1 = new JPanel();
		
		JCheckBox cb2 = new JCheckBox();
		JLabel lb2 = new JLabel("Shrek 2 the DVD");
		JPanel p2 = new JPanel();
		
		JCheckBox cb3 = new JCheckBox();
		JLabel lb3 = new JLabel("Chopsticks");
		JPanel p3 = new JPanel();
		
		JCheckBox cb4 = new JCheckBox();
		JLabel lb4 = new JLabel("Egg");
		JPanel p4 = new JPanel();
		
		JCheckBox cb5 = new JCheckBox();
		JLabel lb5 = new JLabel("Osteoporosis");
		JPanel p5 = new JPanel();
		
		JCheckBox cb6 = new JCheckBox();
		JLabel lb6 = new JLabel("Bone Hurting Juice");
		JPanel p6 = new JPanel();
		
		p1.add(cb1);
		p1.add(lb1);
		
		
		p2.add(cb2);
		p2.add(lb2);
		
		p3.add(cb3);
		p3.add(lb3);
		
		p4.add(cb4);
		p4.add(lb4);
		
		p5.add(cb5);
		p5.add(lb5);
		
		
		p6.add(cb6);
		p6.add(lb6);
		
		weaponPanel.add(p1); weaponPanel.add(p2); weaponPanel.add(p3); weaponPanel.add(p4); weaponPanel.add(p5); weaponPanel.add(p6);
		
		
		//format this weaponPanel
		weaponPanel.setLocation(0,this.getHeight()*2/3 - 30);
		weaponPanel.setSize(this.getWidth()/2, this.getHeight()/3-15);
		TitledBorder border = new TitledBorder("Weapons");
		border.setTitleJustification(TitledBorder.LEFT);
		border.setTitlePosition(TitledBorder.TOP);
		weaponPanel.setBorder(border);
		
		return weaponPanel;
		
	}

}