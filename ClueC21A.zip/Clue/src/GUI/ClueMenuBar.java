package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class ClueMenuBar extends JMenu{


	private static ClueMenuBar thisMenuBar;
	private ClueMenuBar()	{}
	
	private static NotesWindow notesWindow = NotesWindow.getInstance(); //you can move this to GUIManager if you want

	public static ClueMenuBar getInstance()	{
		if (thisMenuBar == null)
			thisMenuBar=new ClueMenuBar();
		return thisMenuBar;
	}

	public void exitButtonClicked(ActionEvent e)	{
		GUIManager.getMainWindow().dispatchEvent(new WindowEvent(GUIManager.getMainWindow(), WindowEvent.WINDOW_CLOSING));
	}

	public void initialize(JFrame parentFrame)	{

		notesWindow.initialize();
		
		JMenu menu, submenu;  
		JMenuItem notes, exit;  
		

		JMenuBar mb=new JMenuBar();  
		menu=new JMenu("Menu");  

		notes=new JMenuItem("Notes");  
		exit=new JMenuItem("Exit");  

		exit.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				exitButtonClicked(e);
			} 
		} );;
		
		notes.addActionListener(e -> notesWindow.setVisible(true));

		menu.add(notes); menu.add(exit);

		mb.add(menu);  
		parentFrame.setJMenuBar(mb);          

	}
}
