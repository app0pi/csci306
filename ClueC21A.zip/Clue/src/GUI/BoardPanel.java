package GUI;

import javax.swing.JFrame;
import javax.swing.JPanel;

import clueGame.Board;

public class BoardPanel extends JPanel {
	private static BoardPanel thisBoardPanel;
	private BoardPanel()	{}

	public static BoardPanel getInstance()	{
		if (thisBoardPanel == null)
			thisBoardPanel=new BoardPanel();
		return thisBoardPanel;
	}
	
	
	public void initialize(JFrame parentFrame)	{
		
	}
	
	public void buildBoard(Board board) {
		
	}
	
}
