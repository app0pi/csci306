package clueGame;

import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class HumanPlayer extends Player {
	public HumanPlayer(String name, Color color, int row, int column)	{
		super(name, color, row, column);
	}
	
	public HumanPlayer()	{
		super();
	}
	
	//maybes:
	
	public void makeAccusation()	{

		
		
	}
	
	public void createSuggestion() {
		Solution suggestion = new Solution();
		
		suggestion.room = Board.getInstance().roomMap.get(Board.getInstance().getCellAt(this.getRow(), this.getColumn()).getInitial());
		
		Set<Card> unseenCards = new HashSet<Card>();
		unseenCards = Board.getInstance().getAllCards();
		unseenCards.removeAll(this.getSeenCards());
		
		for(Card c : unseenCards) {
			if(c.getCardType()==CardType.PERSON) {
				//select rand person card
				suggestion.person = c.getCardName();
			}
			
			if(c.getCardType()==CardType.WEAPON)	{
				suggestion.weapon = c.getCardName();
			}
		}
		
		
		
		Board.getInstance().handleSuggestion(suggestion, this, Board.getInstance().testPlayers);
		
		
		
	}
}
