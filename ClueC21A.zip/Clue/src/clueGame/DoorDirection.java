package clueGame;

public enum DoorDirection {
	UP("U"), RIGHT("R"), DOWN("D"), LEFT("L"), NONE("N");
	
	
	private DoorDirection(String value) {		
		
	}
}