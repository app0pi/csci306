package clueGame;
import java.util.*;

import clueGame.BoardCell;


public class IntBoard {
	private BoardCell[][] grid;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	private Map<BoardCell, Set<BoardCell>> adjMtx;
	private BoardCell startLocation;
	
	public IntBoard()	{
		grid = new BoardCell[4][4];
		calcAdjacencies();
		targets = new HashSet<BoardCell>();
		visited = new HashSet<BoardCell>();
	}
	
	public void calcAdjacencies() {
		
		for(int i=0; i<grid.length; i++) {
			for(int j=0; j<grid[i].length; j++) {
				BoardCell cell = new BoardCell(i,j);
				grid[i][j] = cell;				
			}
		}
		
		adjMtx = new HashMap<BoardCell, Set<BoardCell>>();
		
		for(int i=0; i<grid.length; i++) {
			for(int j=0; j<grid[i].length; j++) {
				
				Set<BoardCell> adjCells = new HashSet<BoardCell>();
				
				//try to get up direction:
				try	{
					adjCells.add(grid[i][j-1]);					
				} catch (Exception e)	{}
				
				//try to get right direction
				try	{
					adjCells.add(grid[i+1][j]);
				} catch (Exception e)	{}
				
				//try to get down direction
				try	{
					adjCells.add(grid[i][j+1]);
				} catch (Exception e)	{}
				
				//try to get left direction
				try	{
					adjCells.add(grid[i-1][j]);
				} catch (Exception e)	{}
				
				adjMtx.put(grid[i][j], adjCells);
				
				
			}
		}
		
		
		
		
	}

	public Set<BoardCell> getAdjList(BoardCell cell)	{
		return adjMtx.get(cell);
	}
	
	public void calcTargets(BoardCell startCell, int pathLength)	{
		
		
		if(pathLength<=0) {
			return;
		}
		
		for (BoardCell adjCell : getAdjList(startCell))	{
			visited.add(startCell);
			
			if(!visited.contains(adjCell))	{
				
				
				visited.add(adjCell);
				//Base Case, pathLength == 1:
				
					//edge case:
					if(pathLength==1)	{
						
						targets.add(adjCell);
						//targets.removeAll(visited);
						//visited.remove(startCell);
						//visited.clear();
					} else	{
					calcTargets(adjCell, pathLength-1);
					
				}				
				
				
				visited.remove(adjCell);
			}
			
			
		
		}
		return;
		
		
	}
	
	public Set<BoardCell> getTargets()	{
		return targets;
	}
	
	public BoardCell getCell(int i, int j) {
		return grid[i][j];
	}
}
