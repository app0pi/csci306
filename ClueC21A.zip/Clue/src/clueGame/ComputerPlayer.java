package clueGame;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class ComputerPlayer extends Player {
	
	public Solution currentSuggestion;
	
	private char roomLastVisited = ' ';
	
	public char getRoomLastVisited() {
		return roomLastVisited;
	}

	public void setRoomLastVisited(char roomLastVisited) {
		this.roomLastVisited = roomLastVisited;
	}

	public ComputerPlayer(String name, Color color, int row, int column) {
		super(name, color, row, column);
		
		
	}
	
	public ComputerPlayer() {
		super();
	}

	public BoardCell pickLocation(Set<BoardCell> targets)	{
	
		Set<BoardCell> rooms = new HashSet<BoardCell>();
		for(BoardCell b: targets) {
			if(b.getInitial()!='W' && b.getInitial()!='X') {
				rooms.add(b);
			}
		}
		

		//if there are room(s) in target
		if(!rooms.isEmpty()) {
			for(BoardCell b: rooms) {
				//if this room was not last visited, then return that room (as boardCell)
				if(b.getInitial()!=this.roomLastVisited) {
					return b;
				}
			}
		}
		
				
		//if no rooms in list if roomLastVisited is not a room
		
		int selection = new Random().nextInt(targets.size());
		int i = 0;
		for(BoardCell b : targets) {
			if(i==selection) {
				return b;
			}
			i++;
		}


		//dummy return statement
		return null;
		
	}
	public void makeAccusation()	{
		Solution predictedSolution = new Solution();
		
		Board myBoard = Board.getInstance();
		
		Set<Card> cardsToGuess = new HashSet<Card>();
		
		for(Card c : myBoard.getAllCards())	{
			
		}
		
		
	}
	
	public void createSuggestion() {
		Solution suggestion = new Solution();
		
		suggestion.room = Board.getInstance().roomMap.get(Board.getInstance().getCellAt(this.getRow(), this.getColumn()).getInitial());
		
		Set<Card> unseenCards = new HashSet<Card>(Board.getInstance().getAllCards());
	
		unseenCards.removeAll(this.getSeenCards());
		
		System.out.println("Size of allCards on Board " + Board.getInstance().getAllCards().size());
		System.out.println("Size of seen cards in class:" + this.getSeenCards().size());
		System.out.println("Size of unseen cards in class:" + unseenCards.size());
		
		List<Card> unseenCardsList = new ArrayList<Card>(unseenCards);
		
		//System.out.println(unseenCardsList.size());
		
	
		
		Collections.shuffle(unseenCardsList);
		
		
		
		
		for(Card c : unseenCardsList) {
			
			//System.out.println("FROM LIST: " + c.getCardName());
			
			if(c.getCardType()==CardType.PERSON) {
				
				suggestion.person = c.getCardName();
			}
			
			if(c.getCardType()==CardType.WEAPON)	{
				suggestion.weapon = c.getCardName();
			}
		}
		
		this.currentSuggestion = suggestion;
		
		//may not work if returns null:
		//this.getSeenCards().add(Board.getInstance().handleSuggestion(suggestion, this, Board.getInstance().testPlayers));
		
		
		
	}
}
