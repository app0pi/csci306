package clueGame;

public class Card {
	private String cardName;
	private CardType cardType;

	public Card(String cardName) {
		super();
		this.cardName = cardName;
	}
	
	public String getCardName() {
		return this.cardName;
	}
	
	public CardType getCardType() {
		return cardType;
	}



	public void setCardType(CardType cardType) {
		this.cardType = cardType;
	}



	public boolean equals(Card card) {
		if (this.cardName == card.cardName)	{
			return true;
		}
		return false;
	}
}
