package clueGame;

public class Solution {
	public String person;
	public String room;
	public String weapon;
	
	public Solution()	{
		
	}
}
