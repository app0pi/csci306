package clueGame;

import java.awt.Color;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public abstract class Player {
	
	private String playerName;
	private int row;
	private int column;
	private Color color;
	private Set<Card> cardHand;
	private Set<Card> seenCards;
	
	
	public Set<Card> getSeenCards() {
		return seenCards;
	}

	public void setSeenCards(Set<Card> seenCards) {
		this.seenCards = seenCards;
	}

	public Card disproveSuggestion(Solution suggestion)	{
		
		Set<Card> matchingCards = new HashSet<Card>();
		//cycle through cardHand to find overlap with our suggestion parameter and store into the set of matching cards
		
		for (Card c : cardHand) {
			if(c.getCardType() == CardType.PERSON) {
				if(c.getCardName()==suggestion.person) {
					matchingCards.add(c);
				}
			}
			if(c.getCardType() == CardType.ROOM) {
				if(c.getCardName()==suggestion.room) {
					matchingCards.add(c);
				}
			}
			if(c.getCardType() == CardType.WEAPON) {
				if(c.getCardName()==suggestion.weapon) {
					matchingCards.add(c);
				}
			}
		}
		
		if(matchingCards.isEmpty()) {
			return null;
		}

		int selection = new Random().nextInt(matchingCards.size());
		int i = 0;
		for(Card c : matchingCards) {
			if(i==selection) {
				return c;
			}
			i++;
		}

		return null;
		
		
	}
	
	public Player(String name, Color color, int row, int column)	{
		this.playerName = name;
		this.color = color;
		this.row = row;
		this.column = column;
		cardHand = new HashSet<Card>();
		seenCards = new HashSet<Card>();
	}

	//Empty constructor
	public Player() {
		cardHand = new HashSet<Card>();
		seenCards = new HashSet<Card>();
	}

	public String getPlayerName() {
		return playerName;
	}
	

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public Set<Card> getCardHand() {
		return cardHand;
	}

	public void setCardHand(Set<Card> seenCards) {
		this.cardHand = seenCards;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}
}
